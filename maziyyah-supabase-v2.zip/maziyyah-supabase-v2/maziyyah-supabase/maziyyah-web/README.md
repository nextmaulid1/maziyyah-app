# Web Maziyyah Generation (Netlify + Supabase)

Isi folder:
- `index.html` : seluruh website (satu file)
- `netlify.toml` : konfigurasi Netlify
- `supabase/schema.sql` : tabel, aturan akses, dan penyimpanan foto profil (versi awal)
- `supabase/migration-v2.sql` : UPGRADE V2 (media, like, komentar, simpan, follow, DM, branding, bahasa)
- `supabase/alumni.json` : data 96 alumni
- `supabase/seed.mjs` : script pembuat 96 akun (jalan sekali)

## Langkah 1. Buat proyek Supabase
1. Buka supabase.com, login, lalu **New project**. Nama bebas, misal `maziyyah`. Pilih region Singapore. Simpan password database di tempat aman.
2. Tunggu proyek selesai dibuat (sekitar 1 sampai 2 menit).

## Langkah 2. Pasang tabel dan aturan akses
1. Menu **SQL Editor** lalu **New query**.
2. Salin seluruh isi `supabase/schema.sql`, tempel, klik **Run**. Harus muncul "Success".

## Langkah 3. Matikan pendaftaran bebas (penting)
Menu **Authentication** lalu **Sign In / Providers** (atau Settings). Matikan **Allow new users to sign up**. Tanpa ini, orang asing bisa bikin akun sendiri dan ikut posting. Akun alumni dibuat lewat script, jadi tetap aman.

## Langkah 4. Ambil kunci
Menu **Project Settings** lalu **API** (atau **API Keys**). Catat tiga hal:
- **Project URL**
- **anon / public key** (boleh ditaruh di index.html)
- **service_role key** (RAHASIA, hanya untuk langkah 5)

## Langkah 5. Buat 96 akun alumni
Di terminal, masuk ke folder `supabase`, lalu:

    npm i @supabase/supabase-js
    SUPABASE_URL=https://XXXX.supabase.co SERVICE_KEY=ISI_SERVICE_ROLE node seed.mjs

(Windows PowerShell: `$env:SUPABASE_URL="..."; $env:SERVICE_KEY="..."; node seed.mjs`)

Harus tercetak `Selesai. Berhasil 96, gagal 0.` Setelah itu, password service_role jangan dipakai lagi dan jangan dibagikan.

## Langkah 6. Sambungkan website
Buka `index.html` di VS Code, cari bagian atas script, isi:

    const SUPABASE_URL="https://XXXX.supabase.co";
    const SUPABASE_KEY="ISI_ANON_PUBLIC_KEY";

Tes lokal dengan ekstensi **Live Server**. Login: nama lengkap alumni (misal `Azka Maulidi`), password `123456`. Setelah masuk pertama, langsung diminta ganti password.

## Langkah 7. Deploy ke Netlify
Cara cepat: buka app.netlify.com/drop lalu seret folder proyek (cukup `index.html` dan `netlify.toml`). Folder `supabase` tidak perlu ikut karena isinya script setup.
Cara rapi: push ke GitHub (tanpa service_role key), lalu di Netlify pilih **Add new site > Import from Git**.

## UPGRADE V2 (sudah punya proyek yang jalan)
Urutan penting: database dulu, baru website.
1. Supabase > **SQL Editor** > **New query** > tempel seluruh `supabase/migration-v2.sql` > **Run**. Aman dijalankan ulang.
2. Cek menu **Storage**: harus ada bucket baru `media` (maks 50 MB per file).
3. Ganti `index.html` di Netlify dengan yang baru (drag-drop folder seperti biasa). `SUPABASE_URL` dan `SUPABASE_KEY` di dalamnya sudah terisi punya proyek lo; kalau ganti proyek, isi ulang.
4. Buka situs, login, lalu coba: posting foto/video, like, komentar, simpan, follow, dan kirim pesan.

Yang baru:
- Layar awal "Masuk ke Ma28iyyah" (username = nama lengkap, atau kode seperti `a001`, plus password). Semua isi situs hanya terlihat setelah login.
- Setelah login langsung ke **Maziyyah Update**: posting teks/foto/video dari galeri, like, komentar, simpan (tab **Tersimpan**).
- **Follow**: buka profil alumni lalu tekan Ikuti. Orang yang kamu ikuti melihat tombol **Ikuti Balik** dan notifikasi di tab **Notifikasi** (angka merah). Setelah saling follow, tombol **Chat** muncul di kedua sisi. **Pesan (DM)** hanya bisa dikirim kalau kalian saling follow (dijaga di database, bukan cuma tampilan).
- Kolom password (login dan ganti password) punya ikon mata untuk melihat/menyembunyikan isinya.
- **Edit Branding** (menu Akun Saya): warna aksen dan latar, tersimpan per akun.
- Bahasa (pojok kanan atas): Indonesia, English, Korea, Jepang, Sunda, Jawa. Pilihan tersimpan per akun. Terjemahan Sunda/Jawa belum dicek penutur asli.

Catatan:
- Foto otomatis dikompres di browser. Video tidak dikompres, jadi batasnya 50 MB. Paket gratis Supabase punya total penyimpanan 1 GB; pantau di Storage.
- Postingan kini hanya bisa dibaca yang sudah login. Berkas foto/video sendiri tetap bisa dibuka siapa pun yang tahu alamat persisnya.
- Sebelum menjalankan migrasi, jangan deploy `index.html` baru: fitur baru akan error karena tabelnya belum ada.

## Catatan
- Tanggal lahir tersimpan di tabel privat dan hanya terlihat oleh pemilik akunnya.
- Lupa password: ganti manual lewat Supabase **Authentication > Users**.
- Akun "username" diambil dari kolom `name`. Kalau ada dua alumni bernama sama, perlu dibedakan namanya.
